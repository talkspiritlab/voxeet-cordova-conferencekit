//
//  VoxeetConferenceKit.h
//  VoxeetConferenceKit
//
//  Created by Coco on 15/02/2017.
//  Copyright © 2017 Voxeet. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VoxeetConferenceKit.
FOUNDATION_EXPORT double VoxeetConferenceKitVersionNumber;

//! Project version string for VoxeetConferenceKit.
FOUNDATION_EXPORT const unsigned char VoxeetConferenceKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VoxeetConferenceKit/PublicHeader.h>


