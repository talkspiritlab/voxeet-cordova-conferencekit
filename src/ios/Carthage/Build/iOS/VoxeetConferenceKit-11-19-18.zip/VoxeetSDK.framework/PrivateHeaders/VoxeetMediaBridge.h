//
//  VoxeetMediaBridge.h
//  
//
//  Created by Barnabe LUX on 25/08/15.
//
//

#import <Foundation/Foundation.h>
#import "MediaAPI.h"
#import "SdpMessage.h"
#import "SdpCandidates.h"

//#import "AudioSession.h"

@interface VoxeetMediaBridge : NSObject

@end
